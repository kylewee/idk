<?php

define('TEXT_MODULE_YANDEX_DISK_TITLE','Яндекс.Диск');
define('TEXT_MODULE_YANDEX_DISK_ACCESS_TOKEN','OAuth-токен');
define('TEXT_MODULE_YANDEX_DISK_ACCESS_TOKEN_INFO','<a href="https://yandex.ru/dev/disk/api/concepts/quickstart.html?lang=ru#quickstart__oauth" target="_balnk">Получение токена для веб-приложения</a>');