<?php

define('TEXT_MODULE_DROPBOX_TITLE','Dropbox');
define('TEXT_MODULE_DROPBOX_ACCESS_TOKEN_INFO','<a href="https://www.dropbox.com/developers/apps" target="_blank">Create a new application to get App key/secret</a>');