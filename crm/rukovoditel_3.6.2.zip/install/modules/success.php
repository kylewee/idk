
<h3 class="page-title"><?php echo TEXT_SUCCESS ?></h3>

<p><?php echo TEXT_INSTALLATION_SUCCESS ?></p>

<input type="button" value="<?php echo TEXT_BUTTON_LOGIN ?>"  class="btn btn-primary" onClick="location.href='../index.php'" >
