https://github.com/spatie/dropbox-api

NOTE: Added custom class includes\libs\FileStorage\Dropbox\1.22.0\vendor\spatie\dropbox-api\src\AutoRefreshingDropBoxTokenService.php
that is not included in baseline.
