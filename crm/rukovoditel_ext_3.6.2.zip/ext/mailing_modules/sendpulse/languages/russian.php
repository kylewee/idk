<?php

define('TEXT_MODULE_SENDPULSE_USER_ID','Ваш API ID');
define('TEXT_MODULE_SENDPULSE_SECRET','Ваш API секрет');