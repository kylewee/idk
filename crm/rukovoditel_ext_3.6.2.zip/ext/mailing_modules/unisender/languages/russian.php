<?php

define('TEXT_MODULE_UNISENDER_API_KEY','Ключ доступа к API');