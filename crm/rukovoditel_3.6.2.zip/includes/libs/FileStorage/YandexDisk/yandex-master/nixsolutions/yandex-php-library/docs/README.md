Yandex PHP Library
==================

Documentation for the  [Yandex PHP Library](https://github.com/nixsolutions/yandex-php-library).

Building the documentation
--------------------------

The documentation is written in [reStructuredText](http://docutils.sourceforge.net/rst.html) and can be built using
[Sphinx](http://sphinx.pocoo.org/).

1. pip install -r requirements.txt
2. Make the HTML documentation: ``make html``
