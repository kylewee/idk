<?php

define('TEXT_MODULE_UNISENDER_API_KEY','API Key');