<?php

define('TEXT_MODULE_CRYPTOPRO_TITLE','КриптоПро');
define('TEXT_MODULE_CRYPTOPRO_','Идентификатор бота (token)');
define('TEXT_MODULE_CRYPTOPRO_CERTIFICATE_IMPRINT','Отпечаток сертификата');
define('TEXT_MODULE_CRYPTOPRO_CERTIFICATE_IMPRINT_INFO','Выберите поле из сущности "Пользователи" в котором хранится отпечаток сертификата.');
