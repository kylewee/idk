CHANGELOG
=========

0.1.0 (2013-08-08)
------------------

* First public release
* Added Pinger package
