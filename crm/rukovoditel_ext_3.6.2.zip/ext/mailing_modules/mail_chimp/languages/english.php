<?php 

define('TEXT_MODULE_MAILCHIMP_TITLE','Mailchimp');
define('TEXT_MODULE_MAILCHIMP_API_KEY','API key');

